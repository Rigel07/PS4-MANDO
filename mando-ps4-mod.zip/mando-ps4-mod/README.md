# Mando PS4 (Forge 1.20.1)

Juega a Minecraft con un mando de PS4 conectado al PC (USB o Bluetooth).
Solo hace falta instalarlo en el cliente.

## Controles en el juego
| Mando | Accion |
|---|---|
| Stick izquierdo | Moverse |
| Stick derecho | Camara |
| X (cruz) | Saltar |
| O (circulo) | Agacharse (mantener) |
| Cuadrado | Cambiar objeto de mano |
| Triangulo | Inventario |
| R2 | Atacar / romper |
| L2 | Usar / colocar |
| L1 / R1 | Barra rapida (anterior / siguiente) |
| L3 (pulsar stick izq.) | Correr |
| R3 (pulsar stick der.) | Copiar bloque |
| Cruceta arriba | Cambiar camara (F5) |
| Cruceta abajo | Tirar objeto |
| Cruceta izquierda | Chat |
| Cruceta derecha | Lista de jugadores (mantener) |
| Share | Logros |
| Options | Menu de pausa |

## Controles en menus e inventario
| Mando | Accion |
|---|---|
| Stick izquierdo | Mover el cursor |
| X (cruz) | Clic izquierdo (mantener para arrastrar) |
| Cuadrado | Clic derecho |
| Triangulo | Mover rapido (shift + clic) |
| O (circulo) | Atras / cerrar |
| Stick derecho | Rueda del raton |
| Cruceta | Flechas del teclado |

## Ajustes
Se crea el archivo `config/mandops4-client.toml` con: zona muerta, velocidad de camara,
velocidad del cursor e invertir eje Y.

## Notas
- Si usas DS4Windows o Steam Input, tambien funciona (el mando se ve como mando estandar).
- El teclado y el raton siguen funcionando a la vez.

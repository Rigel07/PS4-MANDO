package com.mandops4;

import net.minecraftforge.common.ForgeConfigSpec;

public class ControllerConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.DoubleValue DEADZONE;
    public static final ForgeConfigSpec.DoubleValue LOOK_SPEED;
    public static final ForgeConfigSpec.DoubleValue CURSOR_SPEED;
    public static final ForgeConfigSpec.BooleanValue INVERT_LOOK_Y;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("Mando PS4 - ajustes").push("mando");
        ENABLED = b.comment("Activar el soporte de mando")
                .define("enabled", true);
        DEADZONE = b.comment("Zona muerta de los sticks (si la camara se mueve sola, sube este valor)")
                .defineInRange("deadzone", 0.25D, 0.05D, 0.6D);
        LOOK_SPEED = b.comment("Velocidad de la camara con el stick derecho")
                .defineInRange("lookSpeed", 1.0D, 0.2D, 4.0D);
        CURSOR_SPEED = b.comment("Velocidad del cursor en menus e inventario")
                .defineInRange("cursorSpeed", 1.0D, 0.2D, 4.0D);
        INVERT_LOOK_Y = b.comment("Invertir el eje vertical de la camara")
                .define("invertLookY", false);
        b.pop();
        SPEC = b.build();
    }
}

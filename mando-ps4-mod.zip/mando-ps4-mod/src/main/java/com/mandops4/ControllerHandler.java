package com.mandops4;

import com.mojang.blaze3d.platform.Window;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWGamepadState;

import java.util.Arrays;

/**
 * Lee el mando con la API de gamepad de GLFW (el DualShock 4 viene reconocido de serie)
 * y lo convierte en movimiento, camara, acciones y cursor de menus.
 */
@Mod.EventBusSubscriber(modid = MandoPs4Mod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ControllerHandler {

    // Nombres PS4 sobre los botones "estilo Xbox" de GLFW
    private static final int CROSS = GLFW.GLFW_GAMEPAD_BUTTON_A;
    private static final int CIRCLE = GLFW.GLFW_GAMEPAD_BUTTON_B;
    private static final int SQUARE = GLFW.GLFW_GAMEPAD_BUTTON_X;
    private static final int TRIANGLE = GLFW.GLFW_GAMEPAD_BUTTON_Y;
    private static final int L1 = GLFW.GLFW_GAMEPAD_BUTTON_LEFT_BUMPER;
    private static final int R1 = GLFW.GLFW_GAMEPAD_BUTTON_RIGHT_BUMPER;
    private static final int SHARE = GLFW.GLFW_GAMEPAD_BUTTON_BACK;
    private static final int OPTIONS = GLFW.GLFW_GAMEPAD_BUTTON_START;
    private static final int L3 = GLFW.GLFW_GAMEPAD_BUTTON_LEFT_THUMB;
    private static final int R3 = GLFW.GLFW_GAMEPAD_BUTTON_RIGHT_THUMB;
    private static final int DUP = GLFW.GLFW_GAMEPAD_BUTTON_DPAD_UP;
    private static final int DRIGHT = GLFW.GLFW_GAMEPAD_BUTTON_DPAD_RIGHT;
    private static final int DDOWN = GLFW.GLFW_GAMEPAD_BUTTON_DPAD_DOWN;
    private static final int DLEFT = GLFW.GLFW_GAMEPAD_BUTTON_DPAD_LEFT;
    private static final int L2 = 15;
    private static final int R2 = 16;
    private static final int COUNT = 17;

    private static final GLFWGamepadState STATE = GLFWGamepadState.create();
    private static final boolean[] prev = new boolean[COUNT];
    private static final boolean[] cur = new boolean[COUNT];

    private static int jid = -1;
    private static int searchCooldown = 0;
    private static long lastNanos = 0L;

    // Movimiento (lo lee el evento de movimiento del jugador)
    private static float moveX = 0f;
    private static float moveY = 0f;

    private static boolean wasInScreen = false;
    private static boolean dragging = false;
    private static double scrollAcc = 0.0;

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;

        Minecraft mc = Minecraft.getInstance();
        long now = System.nanoTime();
        float dt = lastNanos == 0L ? 0.016f : Math.min((now - lastNanos) / 1.0e9f, 0.1f);
        lastNanos = now;

        moveX = 0f;
        moveY = 0f;

        if (!ControllerConfig.ENABLED.get() || !mc.isWindowActive() || !readGamepad(mc)) {
            releaseHeld(mc);
            return;
        }

        float dz = ControllerConfig.DEADZONE.get().floatValue();

        Screen screen = mc.screen;
        if (screen != null) {
            handleScreen(mc, screen, dt, dz);
        } else {
            wasInScreen = false;
            dragging = false;
            handleGameplay(mc, dt, dz);
        }

        System.arraycopy(cur, 0, prev, 0, COUNT);
    }

    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (moveX == 0f && moveY == 0f) return;

        Input input = event.getInput();
        float forward = -moveY;
        float left = -moveX;
        if (input.shiftKeyDown) {
            forward *= 0.3f;
            left *= 0.3f;
        }
        input.forwardImpulse = forward;
        input.leftImpulse = left;
        input.up = moveY < -0.3f;
        input.down = moveY > 0.3f;
        input.left = moveX < -0.3f;
        input.right = moveX > 0.3f;
    }

    // ------------------------------------------------------------------ gameplay

    private static void handleGameplay(Minecraft mc, float dt, float dz) {
        LocalPlayer player = mc.player;
        if (player == null) return;
        Options o = mc.options;

        // Movimiento con el stick izquierdo
        moveX = dead(STATE.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_X), dz);
        moveY = dead(STATE.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_Y), dz);

        // Acciones mantenidas
        hold(o.keyJump, CROSS);
        hold(o.keyShift, CIRCLE);
        hold(o.keySprint, L3);
        hold(o.keyPlayerList, DRIGHT);
        holdClick(o.keyUse, L2);
        holdClick(o.keyAttack, R2);

        // Acciones de una pulsacion
        if (down(SQUARE)) tap(o.keySwapOffhand);
        if (down(TRIANGLE)) tap(o.keyInventory);
        if (down(R3)) tap(o.keyPickItem);
        if (down(DUP)) tap(o.keyTogglePerspective);
        if (down(DDOWN)) tap(o.keyDrop);
        if (down(DLEFT)) tap(o.keyChat);
        if (down(SHARE)) tap(o.keyAdvancements);
        if (down(OPTIONS)) mc.pauseGame(false);

        // Barra rapida con L1 / R1
        if (!player.isSpectator()) {
            if (down(R1)) {
                player.getInventory().selected = (player.getInventory().selected + 1) % 9;
            }
            if (down(L1)) {
                player.getInventory().selected = (player.getInventory().selected + 8) % 9;
            }
        }

        // Camara con el stick derecho
        if (mc.mouseHandler.isMouseGrabbed()) {
            float rx = curve(dead(STATE.axes(GLFW.GLFW_GAMEPAD_AXIS_RIGHT_X), dz));
            float ry = curve(dead(STATE.axes(GLFW.GLFW_GAMEPAD_AXIS_RIGHT_Y), dz));
            if (rx != 0f || ry != 0f) {
                double speed = 1200.0 * ControllerConfig.LOOK_SPEED.get() * dt;
                double yInv = ControllerConfig.INVERT_LOOK_Y.get() ? -1.0 : 1.0;
                player.turn(rx * speed, ry * speed * yInv);
            }
        }
    }

    // ------------------------------------------------------------------ menus

    private static void handleScreen(Minecraft mc, Screen screen, float dt, float dz) {
        Window win = mc.getWindow();
        long handle = win.getWindow();

        if (!wasInScreen) {
            wasInScreen = true;
            dragging = false;
            scrollAcc = 0.0;
        }

        double[] xs = new double[1];
        double[] ys = new double[1];
        GLFW.glfwGetCursorPos(handle, xs, ys);
        double cx = xs[0];
        double cy = ys[0];

        // Mover el cursor con el stick izquierdo
        float sx = curve(dead(STATE.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_X), dz));
        float sy = curve(dead(STATE.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_Y), dz));
        double speed = 1000.0 * ControllerConfig.CURSOR_SPEED.get() * dt;
        double nx = clamp(cx + sx * speed, 0.0, Math.max(1, win.getScreenWidth() - 1));
        double ny = clamp(cy + sy * speed, 0.0, Math.max(1, win.getScreenHeight() - 1));

        double scaleX = (double) win.getGuiScaledWidth() / (double) win.getScreenWidth();
        double scaleY = (double) win.getGuiScaledHeight() / (double) win.getScreenHeight();
        double gx = nx * scaleX;
        double gy = ny * scaleY;

        boolean moved = nx != cx || ny != cy;
        if (moved) {
            GLFW.glfwSetCursorPos(handle, nx, ny);
            screen.mouseMoved(gx, gy);
            if (dragging && cur[CROSS]) {
                screen.mouseDragged(gx, gy, 0, (nx - cx) * scaleX, (ny - cy) * scaleY);
            }
        }

        // Clic izquierdo (X) y derecho (cuadrado)
        if (down(CROSS)) {
            screen.mouseClicked(gx, gy, 0);
            dragging = true;
        }
        if (up(CROSS)) {
            Screen s = mc.screen;
            if (s != null) s.mouseReleased(gx, gy, 0);
            dragging = false;
        }
        if (down(SQUARE)) {
            Screen s = mc.screen;
            if (s != null) s.mouseClicked(gx, gy, 1);
        }
        if (up(SQUARE)) {
            Screen s = mc.screen;
            if (s != null) s.mouseReleased(gx, gy, 1);
        }

        // Mover rapido (shift + clic) con triangulo
        if (down(TRIANGLE)) {
            Screen s = mc.screen;
            if (s instanceof AbstractContainerScreen<?> cs && !(s instanceof CreativeModeInventoryScreen)) {
                Slot slot = cs.getSlotUnderMouse();
                if (slot != null && mc.gameMode != null && mc.player != null) {
                    mc.gameMode.handleInventoryMouseClick(cs.getMenu().containerId, slot.index, 0,
                            ClickType.QUICK_MOVE, mc.player);
                }
            }
        }

        // Circulo = Escape (cerrar / volver)
        if (down(CIRCLE)) {
            Screen s = mc.screen;
            if (s != null) s.keyPressed(GLFW.GLFW_KEY_ESCAPE, 0, 0);
        }

        // Cruceta = flechas del teclado
        if (down(DUP)) pressKey(mc, GLFW.GLFW_KEY_UP);
        if (down(DDOWN)) pressKey(mc, GLFW.GLFW_KEY_DOWN);
        if (down(DLEFT)) pressKey(mc, GLFW.GLFW_KEY_LEFT);
        if (down(DRIGHT)) pressKey(mc, GLFW.GLFW_KEY_RIGHT);

        // Stick derecho = rueda del raton
        float ry = curve(dead(STATE.axes(GLFW.GLFW_GAMEPAD_AXIS_RIGHT_Y), dz));
        if (ry == 0f) {
            scrollAcc = 0.0;
        } else {
            scrollAcc += -ry * dt * 15.0;
            int steps = (int) scrollAcc;
            if (steps != 0) {
                scrollAcc -= steps;
                Screen s = mc.screen;
                if (s != null) s.mouseScrolled(gx, gy, steps);
            }
        }
    }

    private static void pressKey(Minecraft mc, int key) {
        Screen s = mc.screen;
        if (s != null) s.keyPressed(key, 0, 0);
    }

    // ------------------------------------------------------------------ mando

    private static boolean readGamepad(Minecraft mc) {
        if (jid >= 0 && !GLFW.glfwJoystickPresent(jid)) {
            jid = -1;
            notify(mc, "Mando desconectado");
        }
        if (jid < 0) {
            if (searchCooldown-- > 0) return false;
            searchCooldown = 60;
            for (int i = GLFW.GLFW_JOYSTICK_1; i <= GLFW.GLFW_JOYSTICK_LAST; i++) {
                if (GLFW.glfwJoystickPresent(i) && GLFW.glfwJoystickIsGamepad(i)) {
                    jid = i;
                    String name = GLFW.glfwGetGamepadName(i);
                    notify(mc, "Mando conectado: " + (name == null ? "mando" : name));
                    break;
                }
            }
            if (jid < 0) return false;
        }

        if (!GLFW.glfwGetGamepadState(jid, STATE)) return false;

        for (int i = 0; i < 15; i++) {
            cur[i] = STATE.buttons(i) == GLFW.GLFW_PRESS;
        }
        cur[L2] = STATE.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_TRIGGER) > 0.3f;
        cur[R2] = STATE.axes(GLFW.GLFW_GAMEPAD_AXIS_RIGHT_TRIGGER) > 0.3f;
        return true;
    }

    private static void notify(Minecraft mc, String msg) {
        MandoPs4Mod.LOGGER.info("[Mando PS4] {}", msg);
        LocalPlayer p = mc.player;
        if (p != null) {
            p.displayClientMessage(Component.literal(msg), true);
        }
    }

    /** Suelta las teclas que habia pulsado el mando si se pierde el control. */
    private static void releaseHeld(Minecraft mc) {
        Options o = mc.options;
        if (prev[CROSS]) o.keyJump.setDown(false);
        if (prev[CIRCLE]) o.keyShift.setDown(false);
        if (prev[L3]) o.keySprint.setDown(false);
        if (prev[DRIGHT]) o.keyPlayerList.setDown(false);
        if (prev[L2]) o.keyUse.setDown(false);
        if (prev[R2]) o.keyAttack.setDown(false);
        Arrays.fill(prev, false);
        Arrays.fill(cur, false);
        wasInScreen = false;
        dragging = false;
    }

    // ------------------------------------------------------------------ utilidades

    private static boolean down(int i) {
        return cur[i] && !prev[i];
    }

    private static boolean up(int i) {
        return !cur[i] && prev[i];
    }

    private static void hold(KeyMapping k, int i) {
        if (down(i)) k.setDown(true);
        else if (up(i)) k.setDown(false);
    }

    private static void holdClick(KeyMapping k, int i) {
        if (down(i)) {
            k.setDown(true);
            KeyMapping.click(k.getKey());
        } else if (up(i)) {
            k.setDown(false);
        }
    }

    private static void tap(KeyMapping k) {
        KeyMapping.click(k.getKey());
    }

    private static float dead(float v, float dz) {
        float a = Math.abs(v);
        if (a < dz) return 0f;
        float n = Math.min((a - dz) / (1f - dz), 1f);
        return Math.signum(v) * n;
    }

    private static float curve(float v) {
        return Math.signum(v) * v * v;
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(v, max));
    }
}

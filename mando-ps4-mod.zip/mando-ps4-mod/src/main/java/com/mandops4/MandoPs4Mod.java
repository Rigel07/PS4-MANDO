package com.mandops4;

import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import org.slf4j.Logger;

@Mod(MandoPs4Mod.MODID)
public class MandoPs4Mod {
    public static final String MODID = "mandops4";
    public static final Logger LOGGER = LogUtils.getLogger();

    public MandoPs4Mod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ControllerConfig.SPEC);
    }
}
